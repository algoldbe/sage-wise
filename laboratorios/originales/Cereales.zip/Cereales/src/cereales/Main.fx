
package cereales;

import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.chart.*;
import javafx.scene.chart.part.*;
import javafx.scene.paint.Color;
import javafx.scene.control.*;
import javafx.scene.Cursor;
import javafx.scene.shape.*;
import javafx.scene.text.Font;
import javafx.util.Math ;
import javafx.scene.image.ImageView;
import javafx.scene.image.Image;
import javafx.scene.layout.LayoutInfo;
import javafx.stage.Alert;
import javafx.util.Sequences;
import java.text.DecimalFormat;
import javafx.stage.AppletStageExtension;
/////import java.util.Formattable;
////import javafx.animation.Timeline;

var df; var df2="0.0";/////////trunca a  2 decimales
df = new DecimalFormat("0.00");

//////////////////////variables cambiar de scene
var showScene1 = true; var cont3=0; var vbotones=true;var vinfo=false;
var cont4=0; var y5=0.0;var y52=0.0; var vrec2=false;
var label1=0;var label2=1;var label3=2;var label4=3;

///////////////////////////variables label
var visibilidad=true;
var segmentacion=["por Materia Prima","por Perfil del Consumidor","por Preferencias del Consumidor"];
var segmento1=["AR","V","M","T","D","N","A","U","X","S","NV"];
var ejercicio2=false; var ejercicio3=false;var ejercicio1=true;

/////////////////////variables grafica scene 1
var x=0.0; var x2=0.0;var x3=0.0;var lim2=0.0;
var limsup=0.0;var liminf=0.0;var cont=0;
var z=[0.0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,0.10,0.11,0.12,0.13,0.14,0.15];
var xfinal=[0.0,0.0,0.0,0.0];
var radio=[10.0,10.0,10.0,10.0,10.0];var y=[-6.0,0-6.0,-6.0,-6.0];
var xgrafica1=560.0; var vcuadro=true; var vlabel=true;

//////variables tablas scene 1
    var t1:TextBox;var t2:TextBox;var t3:TextBox;var t4:TextBox;var t5:TextBox;
    var t6:TextBox;var t7:TextBox;var t8:TextBox;var t9:TextBox;var t10:TextBox;
    var t11:TextBox;var t12:TextBox;var t13:TextBox;var t14:TextBox;var t15:TextBox;
    var t16:TextBox;var t17:TextBox;var t18:TextBox;var t19:TextBox;var t20:TextBox;
    var t21:TextBox;var t22:TextBox;var t23:TextBox;var t24:TextBox;var t25:TextBox;
    var t26:TextBox;var t27:TextBox;var t28:TextBox;var t29:TextBox;var t30:TextBox;
    var t35:TextBox; var t36:TextBox;var t37:TextBox;var t38:TextBox;
    var crecimiento1=0.0;var crecimiento2=0.0;var crecimiento3=0.0;var crecimiento4=0.0;
    var crecimientopromedio=0.0;

////////// variables tabla 2 scene 1
    var e1:TextBox; var e2:TextBox;var e3:TextBox;var e4:TextBox;var e5:TextBox;
    var e6:TextBox; var e7:TextBox;var e8:TextBox;var e9:TextBox;var e10:TextBox;
    var e11:TextBox;var e12:TextBox;var e13:TextBox;var e14:TextBox;var e15:TextBox;
    var e16:TextBox;var cont10=0;

    var v5=false; var vflecha=false; var vflechalider=false;
    var xflecha=24; var xflechalider=24;var cont2=0; var erno=true;var vtabla2=false;
    var totalarroz=0.0;var totalavena=0.0; var totalmaiz=0.0; var totaltrigo=0.0;
    var totalalfa=0.0; var totalbeta=0.0; var totalgama=0.0; var totaldelta=0.0;
    var totaltodos=0.0; var por1=0.0; var por2=0.0; var por3=0.0; var por4=0.0;
     
    
////////variables comparacion tabla 2 scene 1
 var text1=[0.0,0.0,0.0,0.0];var text2=[0.0,0.0,0.0,0.0];var text3=0.0;

//////////////////variables indican posicion tabla 2 scene 1
////////////////////////////    0  1  2  3  4  5   6  7  8  9  10    12   14   16    18 19 20
var xy=0; var yx=0; var random=[40,40,70,50,15,20,165,45,20,70,25,30,60,15,4,6,30,30,10,15,0];
var validar=[110,15,235,85,0,45,160,0,15,10,0,30,0,30,10,15];
var numeros2=["0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15"];
var numeros=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15];
var validar2=["10","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15"];
var verror=[false,false,false,false,false,false,false,false,false,false,false,false
,false,false,false,false];
var verror2=[false,false,false,false,false,false,false,false,false,false,false,false
,false,false,false,false];
////////////////////funciones

function xgrafica(xy:Integer,yx:Integer){
     //////////primera columna de la tabla
     if (xy==1){
      text1[0]=numeros[0];text1[1]=numeros[4];text1[2]=numeros[8];text1[3]=numeros[12];
     }////////////segunda columna
      if (xy==2){
      text1[0]=numeros[1];text1[1]=numeros[5];text1[2]=numeros[9];text1[3]=numeros[13];
     }///////////////tercera  columna
     if (xy==3){
      text1[0]=numeros[2];text1[1]=numeros[6];text1[2]=numeros[10];text1[3]=numeros[14];
     }////////////////cuarta  columna
      if (xy==4){
      text1[0]=numeros[3];text1[1]=numeros[7];text1[2]=numeros[11];text1[3]=numeros[15];
     }/////////////////inicia operacion
      text2=Sequences.sort(text1)as Float[];
     if (text1[yx]==text2[3]){
         text3= text1[yx]/ text2[2];x=text3;
         } else{
         text3= text1[yx]/ text2[3];
         x=text3; return x;   }
 }//////////////////////fin fuction
 function xgrafica3(xy:Integer,yx:Integer){
     //////////primera columna de la tabla
     if (xy==1){
      text1[0]=numeros[0];text1[1]=numeros[3];text1[2]=numeros[6];text1[3]=numeros[9];
     }////////////segunda columna
      if (xy==2){
      text1[0]=numeros[1];text1[1]=numeros[4];text1[2]=numeros[7];text1[3]=numeros[10];
     }///////////////tercera  columna
     if (xy==3){
      text1[0]=numeros[2];text1[1]=numeros[5];text1[2]=numeros[8];text1[3]=numeros[11];
     }////////////////cuarta  columna
     text2=Sequences.sort(text1)as Float[];
     if (text1[yx]==text2[3]){
         text3= text1[yx]/ text2[2];x=text3;
         } else{
         text3= text1[yx]/ text2[3];
         x=text3; return x;   }
 }//////////////////////fin fuction

 function random2(){
while (cont2<=19){
 random[cont2]=Math.round(0 + (Math.random() * (100 - 0)));
 cont2++; }
}//////fin fuction random

function obtenerdatos(){
numeros[0]=Integer.parseInt(t1.text);numeros[1]=Integer.parseInt(t7.text);
numeros[2]=Integer.parseInt(t13.text);numeros[3]=Integer.parseInt(t19.text);
numeros[4]=Integer.parseInt(t2.text);numeros[5]=Integer.parseInt(t8.text);
numeros[6]=Integer.parseInt(t14.text);numeros[7]=Integer.parseInt(t20.text);
numeros[8]=Integer.parseInt(t3.text);numeros[9]=Integer.parseInt(t9.text);
numeros[10]=Integer.parseInt(t15.text);numeros[11]=Integer.parseInt(t21.text);
numeros[12]=Integer.parseInt(t4.text);numeros[13]=Integer.parseInt(t10.text);
numeros[14]=Integer.parseInt(t16.text);numeros[15]=Integer.parseInt(t22.text);
}

function obtenerdatos3(){
numeros[0]=Integer.parseInt(t1.text);numeros[1]=Integer.parseInt(t7.text);
numeros[2]=Integer.parseInt(t13.text);numeros[3]=Integer.parseInt(t2.text);
numeros[4]=Integer.parseInt(t8.text);numeros[5]=Integer.parseInt(t14.text);
numeros[6]=Integer.parseInt(t3.text);numeros[7]=Integer.parseInt(t9.text);
numeros[8]=Integer.parseInt(t15.text);numeros[9]=Integer.parseInt(t4.text);
numeros[10]=Integer.parseInt(t10.text);numeros[11]=Integer.parseInt(t16.text);
}


function obtenerdatostabla2(){
numeros2[0]=e1.text;numeros2[1]=e2.text;
numeros2[2]=e3.text;numeros2[3]=e4.text;
numeros2[4]=e5.text;numeros2[5]=e6.text;
numeros2[6]=e7.text;numeros2[7]=e8.text;
numeros2[8]=e9.text;numeros2[9]=e10.text;
numeros2[10]=e11.text;numeros2[11]=e12.text;
numeros2[12]=e13.text;numeros2[13]=e14.text;
numeros2[14]=e15.text;numeros2[15]=e16.text;
}

function calculartotales(){
  totalalfa=numeros[0]+numeros[1]+numeros[2]+numeros[3];
  totalbeta=numeros[4]+numeros[5]+numeros[6]+numeros[7];
  totalgama=numeros[8]+numeros[9]+numeros[10]+numeros[11];
  totaldelta=numeros[12]+numeros[13]+numeros[14]+numeros[15];
  ////////totales vertical x empresa
  totalarroz=numeros[0]+numeros[4]+numeros[8]+numeros[12];
  totalavena=numeros[1]+numeros[5]+numeros[9]+numeros[13];
  totalmaiz=numeros[2]+numeros[6]+numeros[10]+numeros[14];
  totaltrigo=numeros[3]+numeros[7]+numeros[11]+numeros[15];
  totaltodos=totalalfa+totalbeta+totalgama+totaldelta;
}

function calculartotales3(){
  totalalfa=numeros[0]+numeros[1]+numeros[2];
  totalbeta=numeros[3]+numeros[4]+numeros[5];
  totalgama=numeros[6]+numeros[7]+numeros[8];
  totaldelta=numeros[9]+numeros[10]+numeros[11];

  totalarroz=numeros[0]+numeros[3]+numeros[6]+numeros[9];
  totalavena=numeros[1]+numeros[4]+numeros[7]+numeros[10];
  totalmaiz=numeros[2]+numeros[5]+numeros[8]+numeros[11];
   totaltodos=totalalfa+totalbeta+totalgama+totaldelta;
}


  function ejey(){
      var y5=Float.parseFloat(t30.text);
         if (y5> -4.0 and y5< -3.5){ y52=608; }
         if (y5> -3.6 and y5< -2.5){ y52=584; }
         if (y5> -2.6 and y5< -1.5){ y52=564; }
         if (y5> -1.6 and y5<  0.5){ y52=544; }
         if (y5>  0.6 and y5<  1.5){ y52=524; }
         if (y5>  1.6 and y5<  2.5){ y52=500; }
         if (y5>  2.6 and y5<  3.5){ y52=460; }
  }



 function sumarcereales(){
     validar[0]=random[1]+random[3]+random[5];validar[1]=random[4];
     validar[2]=random[2]+random[6];validar[3]=random[0]+random[7];
     validar[4]=random[20];validar[5]=random[10]+random[8];
     validar[6]=random[9]+random[11]+random[12];validar[7]=random[20];
     validar[8]=random[13];validar[9]=random[14]+random[15];
     validar[10]=random[20];validar[11]=random[16];
     validar[12]=random[20];validar[13]=random[17];
     validar[14]=random[18];validar[15]=random[19];
 }

 function sumarcereales2(){
     validar[0]=random[4];  validar[1]=random[1]+random[5];
     validar[2]=random[3]+random[6]+random[0];   validar[3]=random[2]+random[7];////fin alfa
     validar[4]=random[8];   validar[5]=random[12];
     validar[6]=random[9]+random[10]+random[11];  validar[7]=random[20];////beta
     validar[8]=random[20];validar[9]=random[13]+random[14]+random[15]+random[16];
     validar[10]=random[20]; validar[11]=random[20];/////gama
     validar[12]=random[20];validar[13]=random[17];
     validar[14]=random[18];validar[15]=random[19];////delta
 }

 function sumarcereales3(){
     validar[0]=random[4]+random[3]+random[6];
     validar[1]=random[1]+random[5]+random[2]+random[0];
     validar[2]=random[7];//////fin alfa
     validar[3]=random[10];    validar[5]=random[11];
     validar[4]=random[8]+random[9]+random[12];//////fin beta
     validar[6]=random[20]; validar[7]=random[20];
     validar[8]=random[13]+random[14]+random[15]+random[16];////fin gama
     validar[9]=random[20]; validar[10]=random[20];
      validar[11]=random[17]+random[18]+random[19];
 }

function asignardatos(){
    random[0]=40;  random[1]=40;  random[2]=70;  random[3]=50; random[4]=15;
    random[5]=20;  random[6]=165;  random[7]=45;  random[8]=20; random[9]=70;
    random[10]=25;  random[11]=30;  random[12]=60;  random[13]=15;  random[14]=4;
    random[15]=6;  random[16]=30; random[17]=30;  random[18]=10; random[19]=15; random[20]=0;
}

function mostrartotales(){
             t5.text = Float.toString(totalarroz);t11.text = Float.toString(totalavena);
             t17.text = Float.toString(totalmaiz);t23.text = Float.toString(totaltrigo);
             t25.text = Float.toString(totalalfa); t26.text = Float.toString(totalbeta);
             t27.text = Float.toString(totalgama); t28.text = Float.toString(totaldelta);
             t29.text = Float.toString(totaltodos);
}

function mostrartotales3(){
             t5.text = Float.toString(totalarroz);t11.text = Float.toString(totalavena);
             t17.text = Float.toString(totalmaiz);
             t25.text = Float.toString(totalalfa); t26.text = Float.toString(totalbeta);
             t27.text = Float.toString(totalgama); t28.text = Float.toString(totaldelta);
             t29.text = Float.toString(totaltodos);
}
 function asignardatos2(){
      random[4]=15;      random[1]=90; random[5]=60;
      random[3]=100;  random[6]=100;  random[0]=15;  random[2]=30; random[7]=35;///fin alfa
      random[8]=20;   random[12]=65;  random[10]=20; random[11]=40; random[9]=60;
      random[17]=25;    random[18]=15;  random[19]=15;
 }

 function asignardatos3(){
      random[3]=20; random[4]=80; random[6]=40;  random[7]=20;
      random[1]=60; random[5]=120; random[2]=50; random[0]=55;///fin alfa
      random[10]=75;   random[11]=25;
      random[8]=40;random[9]=35;random[12]=30;/////fin beta
      random[14]=10;random[15]=15;random[13]=20;random[16]=10;////fin gama
      random[17]=16;random[18]=24;random[19]=15;
 }

 function limpiarcuadros(){
  t1.text="";t2.text="";t3.text="";t4.text="";t5.text="";t6.text="";t7.text="";
  t8.text="";t9.text="";t10.text="";t11.text="";t12.text="";t13.text="";t14.text="";
  t15.text="";t16.text="";t17.text="";t18.text="";t19.text="";t20.text="";t21.text="";
  t22.text="";t23.text="";t24.text="";t25.text="";t26.text="";t27.text="";t28.text="";
  t29.text="";t30.text="";t35.text="";  t36.text="";t37.text="";t38.text="";
  e1.text="";e2.text="";e3.text="";e4.text="";e5.text="";e6.text="";e7.text="";e8.text="";
  e9.text="";e10.text="";e11.text="";e12.text="";e13.text="";e14.text="";e15.text="";e16.text="";
 }

function validardatos(){
cont2=0;
while (cont2<=15){
    if (validar[cont2]!=numeros[cont2]){
         verror[cont2]=true;
    }///////fin  if
    cont2++;
}/////fin while
}/////////fin function validar

function validardatos2(){
cont2=0;
while (cont2<=15){
    if (validar2[cont2]!=numeros2[cont2]){
         verror2[cont2]=true;
    }///////fin  if
    cont2++;
}/////fin while
}/////////fin function validar

function validardatos3(){
cont2=0;
while (cont2<=11){
    if (validar[cont2]!=numeros[cont2]){
         verror[cont2]=true;
    }///////fin  if
    cont2++;
}/////fin while
}/////////fin function validar

function validardatos4(){
cont2=0;
while (cont2<=11){
    if (validar2[cont2]!=numeros2[cont2]){
         verror2[cont2]=true;
    }///////fin  if
    cont2++;
}/////fin while
}/////////fin function validar
function crecimiento5(){
  por1=Float.parseFloat(t5.text)/Float.parseFloat(t35.text);
              por1=(Math.pow(por1,0.20))-1.0;por1=por1*100;df2=(df.format(por1));
              t6.text = df2;///////porcentaje 2
              por2=Float.parseFloat(t11.text)/Float.parseFloat(t36.text);
              por2=(Math.pow(por2,0.20))-1.0;por2=por2*100;df2=(df.format(por2));
              t12.text = df2;/// ////porcentaje 3
              por3=Float.parseFloat(t17.text)/Float.parseFloat(t37.text);
              por3=(Math.pow(por3,0.20))-1.0;por3=por3*100;df2=(df.format(por3));
              t18.text = df2;  //////porcentaje 4
              por4=Float.parseFloat(t23.text)/Float.parseFloat(t38.text);
              por4=(Math.pow(por4,0.20))-1.0;por4=por4*100;df2=(df.format(por4));
              t24.text =df2;///////crecimiento anual
              }///////fin fuction

   function crecimientohace5(){
  por1=Float.parseFloat(t5.text)/Float.parseFloat(t35.text);
              por1=(Math.pow(por1,0.20))-1.0;por1=por1*100;df2=(df.format(por1));
              t6.text =df2;///////porcentaje 2
              por2=Float.parseFloat(t11.text)/Float.parseFloat(t36.text);
              por2=(Math.pow(por2,0.20))-1.0;por2=por2*100;df2=(df.format(por2));
              t12.text =df2;/// ////porcentaje 3
              por3=Float.parseFloat(t17.text)/Float.parseFloat(t37.text);
              por3=(Math.pow(por3,0.20))-1.0;por3=por3*100;df2=(df.format(por3));
              t18.text =df2;  //////porcentaje 4

              }///////fin fuction

 function crecimientoanual() {
   crecimiento1=Float.parseFloat(t5.text)*Float.parseFloat(t6.text);
   crecimiento2=Float.parseFloat(t11.text)*Float.parseFloat(t12.text);
   crecimiento3=Float.parseFloat(t17.text)*Float.parseFloat(t18.text);
   crecimiento4=Float.parseFloat(t23.text)*Float.parseFloat(t24.text);
   crecimientopromedio=crecimiento1+crecimiento2+crecimiento3+crecimiento4;
   crecimientopromedio=crecimientopromedio/Float.parseFloat(t29.text);
 }


function crecimientoanual3(){
   crecimiento1=Float.parseFloat(t5.text)*Float.parseFloat(t6.text);
   crecimiento2=Float.parseFloat(t11.text)*Float.parseFloat(t12.text);
   crecimiento3=Float.parseFloat(t17.text)*Float.parseFloat(t18.text);
   crecimientopromedio=crecimiento1+crecimiento2+crecimiento3;
   crecimientopromedio=crecimientopromedio/Float.parseFloat(t29.text);
}


function obtenerX(cont3 :Integer){
   x=Float.parseFloat(numeros2[cont3]); //////x=numeros[cont];
  if (x<=0.06 and x>0.0){/////////primer intervalo
       lim2=0; liminf=0;limsup=0.06; liminf=liminf-lim2; limsup=limsup-lim2;
      x=x-lim2; x2=(x*100)/limsup; x3=(x2*2)/100; z[cont3]=x3+0;    }
  if (x<=0.12 and x>0.06){  /////////////segundo intervalo 0.12x
       liminf=0.06;lim2=0.06;limsup=0.12;liminf=liminf-lim2;limsup=limsup-lim2;
       x=x-lim2; x2=(x*100)/limsup; x3=(x2*2)/100; z[cont3]=x3+2; }
  if (x<=0.25 and x>0.12){  //////tercer intervalo 0.25
      liminf=0.12;lim2=0.12;limsup=0.25;liminf=liminf-lim2;limsup=limsup-lim2;
       x=x-lim2; x2=(x*100)/limsup; x3=(x2*2)/100;z[cont3]=x3+4; }
  if (x<=0.5 and x>0.25){ //////cuarto intervalo 0.5
      liminf=0.25;lim2=0.25;limsup=0.50;liminf=liminf-lim2; limsup=limsup-lim2;
     x=x-lim2;x2=(x*100)/limsup; x3=(x2*2)/100;z[cont3]=x3+6;    }
  if (x<=1.0 and x>0.5){ /////qunto  intervalo 1x
      liminf=0.5;lim2=0.5;limsup=1.0;liminf=liminf-lim2;limsup=limsup-lim2;
      x=x-lim2; x2=(x*100)/limsup;x3=(x2*2)/100;z[cont3]=x3+8;}
  if (x<=2.0 and x>1.0){///////  sexto intervalo 2x
     liminf=1.0;lim2=1.0;limsup=2.0; liminf=liminf-lim2; limsup=limsup-lim2;
     x=x-lim2;x2=(x*100)/limsup;x3=(x2*2)/100;z[cont3]=x3+10; }
  if (x<=4.0 and x>2.0){  //////septimo intervalo  4x
     liminf=2.0;lim2=2.0;limsup=4.0;liminf=liminf-lim2;limsup=limsup-lim2;
      x=x-lim2; x2=(x*100)/limsup; x3=(x2*2)/100;z[cont3]=x3+12;   }
  if (x<=8.0 and x>4.0){
     liminf=4.0;lim2=4.0;limsup=8.0;liminf=liminf-lim2;limsup=limsup-lim2;
     x=x-lim2; x2=(x*100)/limsup; x3=(x2*2)/100;z[cont3]=x3+14; }
     }////fin fuction obtener X

////DecimalFormat formateador = new DecimalFormat("####.####");
/////var num = new DecimalFormat("#").parse(text1);

///////////////////////////imagen stock cereales
var cereales: ImageView[] = {
    ImageView {
        x:120
        y:10
        image: Image {
            url: "{__DIR__}imagenes/banner.jpg"
        }    }
 };  /////////cajas cereales
 var pizarron: ImageView[] = {
    ImageView {
        x:4        y:476  visible:bind vinfo
        image: Image {
            url: "{__DIR__}imagenes/info.png"
        }    }
 };  /////////cajas cereales
 var explicacion: ImageView[] = {
    ImageView {
        x:4        y:4
        image: Image {
            url: "{__DIR__}imagenes/explicacion.jpg"
        }    }
 };  //////////////pdf
 var pdf: ImageView[] = {
    ImageView {
        x:768        y:150
        image: Image {
            url: "{__DIR__}imagenes/pdflogo.jpg"
        }    }
 };  ////////fin imagen pdf


 var flechagif: ImageView[] = {
    ImageView {
        x:bind xflechalider
        y:240
        visible:bind vflechalider
        image: Image {
            url: "{__DIR__}imagenes/flecha_abajo.gif"
        }    }
 };  /////////flecha  gif
  var flecha: ImageView[] = {
    ImageView {
        x: bind xflecha
        y:240
        visible:bind vflecha
        image: Image {
            url: "{__DIR__}imagenes/flecha2.gif"
        }    }
 };   ///////flecha  2 tabla 2
  var flecha2: ImageView[] = {
    ImageView {
        x: bind xflecha  
        y:410
        visible:bind vflecha
        image: Image {
            url: "{__DIR__}imagenes/flecha2.gif"
        }    }
 };  ////////////caja roja 1
var croja1: ImageView[] = {
    ImageView {
        x:340   y:20
   cursor:Cursor.HAND
        onMouseClicked: function( e: MouseEvent ):Void  {
       Alert.inform("El numero de cajas en exhibicion es: {random[0]}");
       }/////fin evento
        image: Image {
            url: "{__DIR__}imagenes/r1.png"
        }    }/////imageview
 }; ////////fin var caja roja  1
var croja2: ImageView[] = {
    ImageView {
        x:340   y:60
   cursor:Cursor.HAND
        onMouseClicked: function( e: MouseEvent ):Void  {
       Alert.inform("El numero de cajas en exhibicion es: {random[1]}");
       }/////fin evento
        image: Image {
            url: "{__DIR__}imagenes/r2.png"
        }    }/////imageview
 }; ////////fin var caja roja  2
 var croja3: ImageView[] = {
    ImageView {
        x:340   y:100
   cursor:Cursor.HAND
        onMouseClicked: function( e: MouseEvent ):Void  {
       Alert.inform("El numero de cajas en exhibicion es: {random[2]}");
       }/////fin evento
        image: Image {
            url: "{__DIR__}imagenes/r3.png"
        }    }/////imageview
 }; ////////fin var caja roja  3
 var croja4: ImageView[] = {
    ImageView {
        x:340   y:140
   cursor:Cursor.HAND
        onMouseClicked: function( e: MouseEvent ):Void  {
       Alert.inform("El numero de cajas en exhibicion es: {random[3]}");
       }/////fin evento
        image: Image {
            url: "{__DIR__}imagenes/r4.png"
        }    }/////imageview
 }; ////////fin var caja roja  4
 var croja5: ImageView[] = {
    ImageView {
        x:420   y:20
   cursor:Cursor.HAND
        onMouseClicked: function( e: MouseEvent ):Void  {
       Alert.inform("El numero de cajas en exhibicion es: {random[4]}");
       }/////fin evento
        image: Image {
            url: "{__DIR__}imagenes/r5.png"
        }    }/////imageview
 }; ////////fin var caja roja 5
 var croja6: ImageView[] = {
    ImageView {
        x:420   y:60
   cursor:Cursor.HAND
        onMouseClicked: function( e: MouseEvent ):Void  {
       Alert.inform("El numero de cajas en exhibicion es: {random[5]}");
       }/////fin evento
        image: Image {
            url: "{__DIR__}imagenes/r6.png"
        }    }/////imageview
 }; ////////fin var caja roja 6
 var croja7: ImageView[] = {
    ImageView {
        x:420   y:100
   cursor:Cursor.HAND
        onMouseClicked: function( e: MouseEvent ):Void  {
       Alert.inform("El numero de cajas en exhibicion es: {random[6]}");
       }/////fin evento
        image: Image {
            url: "{__DIR__}imagenes/r7.png"
        }    }/////imageview
 }; ////////fin var caja roja
 var croja8: ImageView[] = {
    ImageView {
        x:420   y:140
   cursor:Cursor.HAND
        onMouseClicked: function( e: MouseEvent ):Void  {
       Alert.inform("El numero de cajas en exhibicion es: {random[7]}");
       }/////fin evento
        image: Image {
            url: "{__DIR__}imagenes/r8.png"
        }    }/////imageview
 }; ////////fin var caja roja 8
var cverde1: ImageView[] = {
    ImageView {
        x:500   y:20
   cursor:Cursor.HAND
        onMouseClicked: function( e: MouseEvent ):Void  {
       Alert.inform("El numero de cajas en exhibicion es: {random[8]}");
       }/////fin evento
        image: Image {
            url: "{__DIR__}imagenes/v1.png"
        }    }/////imageview
 }; ////////fin var caja verde 1
 var cverde2: ImageView[] = {
    ImageView {
        x:500   y:60
   cursor:Cursor.HAND
        onMouseClicked: function( e: MouseEvent ):Void  {
       Alert.inform("El numero de cajas en exhibicion es: {random[9]}");
       }/////fin evento
        image: Image {
            url: "{__DIR__}imagenes/v2.png"
        }    }/////imageview
 }; ////////fin var caja verde 2
 var cverde3: ImageView[] = {
    ImageView {
        x:500   y:100
   cursor:Cursor.HAND
        onMouseClicked: function( e: MouseEvent ):Void  {
       Alert.inform("El numero de cajas en exhibicion es: {random[10]}");
       }/////fin evento
        image: Image {
            url: "{__DIR__}imagenes/v4.png"
        }    }/////imageview
 }; ////////fin var caja verde 3
 var cverde4: ImageView[] = {
    ImageView {
        x:500   y:140
   cursor:Cursor.HAND
        onMouseClicked: function( e: MouseEvent ):Void  {
       Alert.inform("El numero de cajas en exhibicion es: {random[11]}");
       }/////fin evento
        image: Image {
            url: "{__DIR__}imagenes/v5.png"
        }    }/////imageview
 }; ////////fin var caja verde  4
 var cverde5: ImageView[] = {
    ImageView {
        x:580   y:20
   cursor:Cursor.HAND
        onMouseClicked: function( e: MouseEvent ):Void  {
       Alert.inform("El numero de cajas en exhibicion es: {random[12]}");
       }/////fin evento
        image: Image {
            url: "{__DIR__}imagenes/v6.png"
        }    }/////imageview
 }; ////////fin var caja verde  5
 
 var camar1: ImageView[] = {
    ImageView {
        x:580   y:100
   cursor:Cursor.HAND
        onMouseClicked: function( e: MouseEvent ):Void  {
       Alert.inform("El numero de cajas en exhibicion es: {random[14]}");
       }/////fin evento
        image: Image {
            url: "{__DIR__}imagenes/a1.png"
        }    }/////imageview
 }; ////////fin var caja amarilla 1
 var camar2: ImageView[] = {
    ImageView {
        x:580   y:140
   cursor:Cursor.HAND
        onMouseClicked: function( e: MouseEvent ):Void  {
       Alert.inform("El numero de cajas en exhibicion es: {random[15]}");
       }/////fin evento
        image: Image {
            url: "{__DIR__}imagenes/a2.png"
        }    }/////imageview
 }; ////////fin var caja amarilla 2
var camar3: ImageView[] = {
    ImageView {
        x:640   y:20
   cursor:Cursor.HAND
        onMouseClicked: function( e: MouseEvent ):Void  {
       Alert.inform("El numero de cajas en exhibicion es: {random[13]}");
       }/////fin evento
        image: Image {
            url: "{__DIR__}imagenes/a3.png"
        }    }/////imageview
 }; ////////fin var caja amarilla 3
var camar4: ImageView[] = {
    ImageView {
        x:580   y:60
   cursor:Cursor.HAND
        onMouseClicked: function( e: MouseEvent ):Void  {
       Alert.inform("El numero de cajas en exhibicion es: {random[16]}");
       }/////fin evento
        image: Image {
            url: "{__DIR__}imagenes/a4.png"
        }    }/////imageview
 }; ////////fin var caja amarilla 4
 var cazul: ImageView[] = {
    ImageView {
        x:640   y:60
   cursor:Cursor.HAND
        onMouseClicked: function( e: MouseEvent ):Void  {
       Alert.inform("El numero de cajas en exhibicion es: {random[17]}");
       }/////fin evento
        image: Image {
            url: "{__DIR__}imagenes/az3.png"
        }    }/////imageview
 }; ////////fin var caja azul  1
var cazul1: ImageView[] = {
    ImageView {
        x:640   y:100
   cursor:Cursor.HAND
        onMouseClicked: function( e: MouseEvent ):Void  {
       Alert.inform("El numero de cajas en exhibicion es: {random[18]}");
       }/////fin evento
        image: Image {
            url: "{__DIR__}imagenes/az1.png"
        }    }/////imageview
 }; ////////fin var caja azul  1
var cazul2: ImageView[] = {
    ImageView {
        x:640   y:140
   cursor:Cursor.HAND
        onMouseClicked: function( e: MouseEvent ):Void  {
       Alert.inform("El numero de cajas en exhibicion es: {random[19]}");
       }/////fin evento
        image: Image {
            url: "{__DIR__}imagenes/az2.png"
        }    }/////imageview
 }; ////////fin var caja azul  1
 var error: ImageView[] = {
    ImageView {
    x:28   y:300   visible:bind verror[0]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror[0]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg"    }    }/////imageview
 }; ////////fin imagen error  1
 var error1: ImageView[] = {
    ImageView {
    x:28   y:320   visible:bind verror[1]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror[1]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg"    }    }/////imageview
 }; ////////fin imagen error  1
 var error2: ImageView[] = {
    ImageView {
    x:28   y:340   visible:bind verror[2]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror[2]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg"    }    }/////imageview
 }; ////////fin imagen error  2
 var error3: ImageView[] = {
    ImageView {
    x:28   y:360  visible:bind verror[3]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror[3]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg"    }    }/////imageview
 }; ////////fin imagen error  3
var error4: ImageView[] = {
    ImageView {
    x:80   y:300   visible:bind verror[4]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror[4]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg"    }    }/////imageview
 }; ////////fin imagen error  4
var error5: ImageView[] = {
    ImageView {
    x:80   y:320   visible:bind verror[5]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror[5]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg"    }    }/////imageview
 }; ////////fin imagen error  5
var error6: ImageView[] = {
    ImageView {
    x:80   y:340   visible:bind verror[6]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror[6]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg"    }    }/////imageview
 }; ////////fin imagen error  6
var error7: ImageView[] = {
    ImageView {
    x:80   y:360   visible:bind verror[7]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror[7]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg"    }    }/////imageview
 }; ////////fin imagen error  7
var error8: ImageView[] = {
    ImageView {
    x:134   y:300   visible:bind verror[8]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror[8]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg"    }    }/////imageview
 }; ////////fin imagen
var error9: ImageView[] = {
    ImageView {
    x:134   y:320   visible:bind verror[9]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror[9]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg"    }    }/////imageview
 }; ////////fin imagen
var error10: ImageView[] = {
    ImageView {
    x:134   y:340   visible:bind verror[10]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror[10]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg"    }    }/////imageview
 }; ////////fin imagen
var error11: ImageView[] = {
    ImageView {
    x:134   y:360   visible:bind verror[11]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror[11]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg"    }    }/////imageview
 }; ////////fin imagen
var error12: ImageView[] = {
    ImageView {
    x:190   y:300   visible:bind verror[12]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror[12]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg"    }    }/////imageview
 }; ////////fin imagen
var error13: ImageView[] = {
    ImageView {
    x:190   y:320   visible:bind verror[13]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror[13]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg"    }    }/////imageview
 }; ////////fin imagen
var error14: ImageView[] = {
    ImageView {
    x:190   y:340   visible:bind verror[14]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror[14]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg"    }    }/////imageview
 }; ////////fin imagen
var error15: ImageView[] = {
    ImageView {
    x:190   y:360   visible:bind verror[15]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror[15]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg"    }    }/////imageview
 }; ////////fin imagen
 /////////////////////////////////////////////////////imagenes error tabla 2
 var alerta: ImageView[] = {
    ImageView {
    x:28   y:470   visible:bind verror2[0]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror2[0]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg" } } }; //////////////
var alerta2: ImageView[] = {
    ImageView {
    x:83   y:470   visible:bind verror2[1]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror2[1]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg" } } }; //////////////
var alerta3: ImageView[] = {
    ImageView {
    x:138   y:470   visible:bind verror2[2]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror2[2]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg" } } }; //////////////
var alerta4: ImageView[] = {
    ImageView {
    x:194   y:470   visible:bind verror2[3]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror2[3]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg" } } }; //////////////
  var alerta5: ImageView[] = {
    ImageView {
    x:28   y:490   visible:bind verror2[4]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror2[4]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg" } } }; //////////////
 var alerta6: ImageView[] = {
    ImageView {
    x:83   y:490   visible:bind verror2[5]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror2[5]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg" } } }; //////////////
var alerta7: ImageView[] = {
    ImageView {
    x:138   y:490   visible:bind verror2[6]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror2[6]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg" } } }; //////////////
var alerta8: ImageView[] = {
    ImageView {
    x:194   y:490   visible:bind verror2[7]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror2[7]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg" } } }; //////////////
var alerta9: ImageView[] = {
    ImageView {
    x:28   y:510   visible:bind verror2[8]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror2[8]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg" } } }; //////////////
var alerta10: ImageView[] = {
    ImageView {
    x:83   y:510   visible:bind verror2[9]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror2[9]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg" } } }; //////////////
 //////////////////////////////////////////////fin imagenes error
var alerta11: ImageView[] = {
    ImageView {
    x:138   y:510   visible:bind verror2[10]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror2[10]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg" } } }; //////////////
var alerta12: ImageView[] = {
    ImageView {
    x:194   y:510   visible:bind verror2[11]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror2[11]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg" } } }; //////////////
var alerta13: ImageView[] = {
    ImageView {
    x:24   y:530   visible:bind verror2[12]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror2[12]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg" } } }; //////////////
var alerta14: ImageView[] = {
    ImageView {
    x:84   y:530   visible:bind verror2[13]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror2[13]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg" } } }; //////////////
var alerta15: ImageView[] = {
    ImageView {
    x:138   y:530   visible:bind verror2[14]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror2[14]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg" } } }; //////////////
var alerta16: ImageView[] = {
    ImageView {
    x:194   y:530   visible:bind verror2[15]     cursor:Cursor.HAND
    onMouseClicked: function( e: MouseEvent ):Void  {
    verror2[15]=false;    }/////fin evento
   image: Image {   url: "{__DIR__}imagenes/error.jpg" } } }; //////////////


/////////////////////////////////////////stage
Stage {
  title: "Segmentación de Negocios"
   width: 1000
   height: 720
     scene :Scene    {
          content:
          [
          cereales,flechagif,flecha,flecha2,croja1,croja2,croja3,croja4,croja5,croja6,
          croja7,croja8,cverde1,cverde2,cverde3,cverde4,cverde5,camar1,
          camar2,camar3,camar4,cazul,cazul1,cazul2,pizarron, pdf,

          ///////////////  hipervinculo   ///////////////////////
           Hyperlink {
                text: "Ver Instrucciones"  translateX:754  translateY:206
                action: function() {
                       AppletStageExtension.showDocument("http://sage-wise.mx/LMS/__material/apps/Laboratorio_Segmentacion/Instructivo_Segmentador.pdf","_blank");
                } }


  ////////////boton cambiar scene 2
         Button {
          text: "Materia Prima"
          translateX:20     translateY:600
          cursor:Cursor.HAND      visible:bind vbotones
          onMouseClicked: function( e: MouseEvent ):Void  {
              cont4=0;label1=0;label2=1;label3=2;label4=3;visibilidad=true;v5=false;
              asignardatos();ejercicio1=true; ejercicio2=false;ejercicio3=false; limpiarcuadros();
                  t35.text="78";t36.text="87";t37.text="358";t38.text="143";

              }   }
         Button {
          text: "Perfil Consumidor"
          translateX:140     translateY:600
          cursor:Cursor.HAND      visible:bind vbotones
          onMouseClicked: function( e: MouseEvent ):Void  {
              cont4=1;label1=4;label2=5;label3=6;label4=7;visibilidad=true;v5=false;
              asignardatos2(); ejercicio2=true;ejercicio3=false;ejercicio1=false; limpiarcuadros();
                  t35.text="45";t36.text="259";t37.text="269";t38.text="91";
            
              }
          }/////////////fin boton
          Button {
          text: "Preferencias  Consumidor"
          translateX:280     translateY:600
          cursor:Cursor.HAND      visible:bind vbotones
          onMouseClicked: function( e: MouseEvent ):Void  {
              cont4=2;label1=8;label2=9;label3=10; label4=11; visibilidad=false;
               ejercicio3=true;ejercicio2=false;ejercicio1=false; v5=false;
              asignardatos3(); limpiarcuadros();
                t35.text="177";t36.text="336";t37.text="143";t38.text="90";
             }
          }/////////////fin boton B

          /////////////////////////////////////////////grafica 1
 BubbleChart {
        scaleBubbleRadiusUsingAxis: false
        legendVisible:false
        translateX:bind xgrafica1
        translateY:260
        layoutInfo: LayoutInfo {width: 400 height:400}
        //// title : "Segmentacion Materia Prima"
                xAxis : NumberAxis{
                    lowerBound:0
                    upperBound : 16
                    visible:true
                    axisStrokeWidth: 1
                    label:"Posicion competitiva relativa"
                    tickLabelsVisible: false
                    tickUnit : 2

                }
                yAxis : NumberAxis{
                    lowerBound: -4
                    upperBound :12
                    tickUnit: 2
                    label: "Crecimiento anual del Sector %"
                    visible: true
                    tickLabelsVisible: true
                    }
        data: [
            BubbleChart.Series {

                data: [
                    ////////primer circulo
                    BubbleChart.Data {
                     xValue: bind  xfinal[0]
                     yValue: bind y[0]
                     radius: bind radio[0]
                     }    /////////segundo circulo
                    BubbleChart.Data {
                     xValue: bind xfinal[1]
                     yValue: bind y[1]
                     radius: bind radio[1]
                     fill: Color.YELLOWGREEN
                   } //////tercer  circulo
                      BubbleChart.Data {
                     xValue: bind xfinal[2]
                     yValue: bind y[2]
                     radius: bind radio[2]
                     fill: Color.BLUEVIOLET
                   } ////////cuarto  circulo
                    BubbleChart.Data {
                     xValue: bind xfinal[3]
                     yValue: bind y[3]
                     radius: bind radio[3]
                     fill: Color.FIREBRICK
                   } //////fin circulos

                ]//////data
            }///////buble chart series
         ]////////////data grafica
        }///////////////////////////////////////////////////fin grafica
Rectangle {  //////rec 1
    x:784  y:270
    fill: Color.GREEN
    width:4  height:336
}//////rec 2
Rectangle {  //////rec 1
    x:624  y:bind y52  visible:bind vrec2
    fill: Color.GREEN
    width:400  height:4
}//////rec 2
/////////////////////////// textbox tabla 1 y
/////////////////////////////////////////////tabla scene 3
            t1= TextBox{  /////////textbox alfa arroz
                promptText:"0"
                translateX:24
                translateY:300
                columns:6  
            }////////textbox  beta arroz
             t2= TextBox{
                promptText:"0"
                translateX:79                translateY:300
                columns:6 
            }////////textbox gama arroz
             t3= TextBox{
                promptText:"0"
                translateX:134                translateY:300
                columns:6
            }////////textbox delta  arroz
            t4= TextBox{
                promptText:"0"
                translateX:189                translateY:300
                columns:6
            }////////textbox total  arroz
             t5= TextBox{
                promptText:"0"
                translateX:264                translateY:300
                columns:6
                editable:false   focusTraversable:false
            }/////////////crecimiento arroz
             t6= TextBox{
                promptText:"0 % "
                translateX:464                translateY:300
                columns:6
                editable:false   focusTraversable:false
            }////////// textbox alfa avena
             t7= TextBox{
                promptText:"0 "
                translateX:24                translateY:320
                columns:6
            }////////// textbox beta avena avena
             t8= TextBox{
                promptText:"0 "
                translateX:79                translateY:320
                columns:6
            }////////// textbox gama avena
            t9= TextBox{
                promptText:"0 "
                translateX:134                translateY:320
                columns:6
            }////////// textbox delta avena
            t10= TextBox{
                promptText:"0 "
                translateX:189                translateY:320
                columns:6
            }////////// textbox total  avena
            t11= TextBox{
                promptText:"0 "
                translateX:264                translateY:320
                columns:6
                editable:false   focusTraversable:false
            }////////// textbox crecimiento avena
            t12= TextBox{
                promptText:"0 %"
                translateX:464                translateY:320
                columns:6
                editable:false   focusTraversable:false
            }////////// textbox alfa maiz
            t13= TextBox{
                promptText:"0 "
                translateX:24                translateY:340
                columns:6
            }////////// textbox maiz beta
            t14= TextBox{
                promptText:"0 "
                translateX:79        translateY:340
                columns:6
            }////////// textbox maiz gama
            t15= TextBox{
                promptText:"0 "
                translateX:134       translateY:340
                columns:6
            }////////// textbox maiz delta
            t16= TextBox{
                promptText:"0 "
                translateX:189       translateY:340
                columns:6  
            }////////// textbox maiz total
            t17= TextBox{
                promptText:"0 "
                translateX:264       translateY:340
                columns:6
                editable:false    focusTraversable:false
            }////////// textbox maiz porcentaje
            t18= TextBox{
                promptText:"0 %"
                translateX:464       translateY:340
                columns:6
                editable:false   focusTraversable:false
            }////////// textbox trigo  alfa
            t19= TextBox{
                promptText:"0 "
                translateX:24       translateY:360
                columns:6   visible:bind visibilidad;
            }////////// textbox trigo beta
            t20= TextBox{
                promptText:"0 "
                translateX:79        translateY:360
                columns:6     visible:bind visibilidad;
            }////////// textbox trigo gama
            t21= TextBox{
                promptText:"0 "
                translateX:134      translateY:360
                columns:6   visible:bind visibilidad;
            }////////// textbox trigo delta
            t22= TextBox{
                promptText:"0 "
                translateX:189        translateY:360
                columns:6   visible:bind visibilidad;
            }////////// textbox trigo total
            t23= TextBox{
                promptText:"0 "
                translateX:264         translateY:360
                columns:6   visible:bind visibilidad;
                editable:false    focusTraversable:false
            }////////// textbox trigo crecimiento
            t24= TextBox{
                promptText:"t24"
                translateX:464       translateY:360
                columns:6   visible:bind visibilidad;
                editable:false   focusTraversable:false
            }////////// textbox total alfa
            t25= TextBox{
                promptText:"0 "
                translateX:24       translateY:380
                columns:6
                editable:false    focusTraversable:false
            }////////// textbox total beta
             t26= TextBox{
                promptText:"0 "
                translateX:79         translateY:380
                columns:6
                editable:false   focusTraversable:false
            }////////// textbox total gama
             t27= TextBox{
                promptText:"0 "
                translateX:134      translateY:380
                columns:6
                editable:false    focusTraversable:false
            }////////// textbox total delta
             t28= TextBox{
                promptText:"0 "
                translateX:189       translateY:380
                columns:6
                editable:false    focusTraversable:false
            }////////// textbox total todos
             t29= TextBox{
                promptText:"0 "
                translateX:264       translateY:380
                columns:6
                editable:false  focusTraversable:false
            }////////// textbox total crecimiento industria
             t30= TextBox{
                promptText:"3 %"
                translateX:464        translateY:380
                columns:6
                editable:false   focusTraversable:false
            }////////// textbox total beta
/////////////////////crecimiento hace 5 años
            t35= TextBox{
                translateX:354         translateY:300   
                columns:6            text:"78"
                editable:false     visible:bind v5       }//////////
             t36= TextBox{
                translateX:354    translateY:320       columns:6
                text:"87"        editable:false     
                visible:bind v5       }//////////
             t37= TextBox{
                translateX:354        translateY:340   
                columns:6       text:"358"
                editable:false     visible:bind v5        }//////////
             t38= TextBox{
                translateX:354    translateY:360   columns:6
                text:"143"        editable:false    
                visible:bind v5      }/////////////////
            
///////////////////botones tabla 1 scene 1
         Button    {
             text: "Calcular "
             translateX:178
             translateY:400
             cursor:Cursor.HAND
             action:function(){         
               
                if (ejercicio1) {  ////////ejercicio  1 materia prima
                 obtenerdatos();sumarcereales();
                 validardatos();cont2=0;erno=true;
                 while (cont2<=15){
                    if (verror[cont2]!=false){
                      erno=false;} cont2++;  }
                      if (erno==true){
                         calculartotales(); vtabla2=true; mostrartotales(); }
             }  /////fin ejercicio 1

             ///////////ejercicio 2 perfil del consumidor
                 if (ejercicio2){
                  obtenerdatos();sumarcereales2();         
                  validardatos();cont2=0;erno=true;
                  while (cont2<=15){
                    if (verror[cont2]!=false){
                      erno=false;} cont2++;  }
                      if (erno==true){//////datos correctos
                         calculartotales(); vtabla2=true; mostrartotales(); }
             }///////fin ejercicio  2

            if (ejercicio3){/////////////ejercicio 3
                  obtenerdatos3(); sumarcereales3(); validardatos3();
                  cont10=0;erno=true;
                  while (cont10<=11){
                       if (verror[cont2]!=false){
                       erno=false;} cont10 ++;   }/// fin while buscando errores
                        if (erno==true){/////si no hay errores
                         calculartotales3();  vtabla2=true;mostrartotales3(); }
                     }/////if ejercicio  3

             }////fin action
             }//// fin boton

//////////////boton crecimiento anual promedio
             Button    {//////calcular 2
             text: "Calcular"
             translateX:460
             translateY:400
             cursor:Cursor.HAND
             action:function(){
             if (v5==true) { ////crecimiento hace 5 años
               if (ejercicio3){
                crecimientohace5(); crecimientoanual3();df2=(df.format(crecimientopromedio));
                t30.text =df2; 
                }else {               
                crecimiento5(); crecimientoanual(); df2=(df.format(crecimientopromedio));
                t30.text =df2;    }   }
               }   }///////fin boton %

             //////////////////////////////////////////boton hace 5 años
              Button    {
             text: "Hace 5 años"
             translateX:340
             translateY:400
             cursor:Cursor.HAND
             action:function(){
                    v5=true;
            
             }/////fin fuction
             }///////fin boton años
              Button    {
             text: "Informacion"
             translateX:620
             translateY:200
             cursor:Cursor.HAND
             action:function(){
            //////random2(); Alert.inform("Datos Modificados con exito");
            if (vinfo==true){
                vinfo=false;vbotones=true;vtabla2=true;
            }else {
            vbotones=false; vinfo=true;vtabla2=false; }
             }  } /////fin boton datos

////////////////////////boton graficar
 Button    {
             text: "Graficar Alfa "
             translateX:300            translateY:470
             cursor:Cursor.HAND      visible:bind vbotones
             action:function(){                
             if (ejercicio3) {
               obtenerdatostabla2();validardatos4();cont2=0;erno=true;
               while (cont2<=15){
                if (verror2[cont2]!=false){
                 erno=false;} cont2++;  }/// fin while
                 if (erno!=false){  ejey();  vrec2=true;
                 cont3=0; obtenerX(cont3); xfinal[0]=z[0];
                 cont3=4; obtenerX(cont3); xfinal[1]=z[4];
                 cont3=8; obtenerX(cont3); xfinal[2]=z[8];
                 y[0]=Float.parseFloat(t6.text);y[1]=Float.parseFloat(t12.text); y[2]=Float.parseFloat(t18.text);
                 radio[0]=Float.parseFloat(t1.text)/3; radio[1]=Float.parseFloat(t7.text)/3;
                radio[2]=Float.parseFloat(t13.text)/3;radio[3]=0; } /////fin if sin errores

             }else {
               obtenerdatostabla2();validardatos2();cont2=0;erno=true;             
             while (cont2<=15){
             if (verror2[cont2]!=false){
                erno=false;} cont2++;  }/// fin while
               if (erno!=false){  ejey();  vrec2=true;
                cont3=0; obtenerX(cont3); xfinal[0]=z[0];
                cont3=4; obtenerX(cont3); xfinal[1]=z[4];
                cont3=8; obtenerX(cont3); xfinal[2]=z[8];
                cont3=12; obtenerX(cont3); xfinal[3]=z[12];
                y[0]=Float.parseFloat(t6.text);y[1]=Float.parseFloat(t12.text);
                y[2]=Float.parseFloat(t18.text);y[3] =Float.parseFloat(t24.text);
                radio[0]=Float.parseFloat(t1.text)/3; radio[1]=Float.parseFloat(t7.text)/3;
                radio[2]=Float.parseFloat(t13.text)/3;radio[3]=Float.parseFloat(t19.text)/3;
                 }////////if busca errores
             }  //////else  if
             }}/////////////////fin boton alfa

Button    {
             text: "Graficar Beta "
             translateX:300             translateY:494
             cursor:Cursor.HAND         visible:bind vbotones
             action:function(){
            
             if (ejercicio3) {
               obtenerdatostabla2();validardatos4();cont2=0;erno=true;
               while (cont2<=15){
                if (verror2[cont2]!=false){
                 erno=false;} cont2++;  }/// fin while
                 if (erno!=false){  ejey();  vrec2=true;
                 cont3=1; obtenerX(cont3); xfinal[0]=z[1];
                 cont3=5; obtenerX(cont3); xfinal[1]=z[5];
                 cont3=9; obtenerX(cont3); xfinal[2]=z[9];
                 y[0]=Float.parseFloat(t6.text);y[1]=Float.parseFloat(t12.text); y[2]=Float.parseFloat(t18.text);
                 radio[0]=Float.parseFloat(t2.text)/3; radio[1]=Float.parseFloat(t2.text)/3;
                radio[2]=Float.parseFloat(t14.text)/3;radio[3]=0; } /////fin if sin errores

             }else {
             while (cont2<=15){
             if (verror2[cont2]!=false){
                erno=false;} cont2++;  }/// fin while
               if (erno!=false){  ejey();  vrec2=true;
                cont3=1; obtenerX(cont3); xfinal[0]=z[1];
                cont3=5; obtenerX(cont3); xfinal[1]=z[5];
                cont3=9; obtenerX(cont3); xfinal[2]=z[9];
                cont3=13; obtenerX(cont3); xfinal[3]=z[13];
                y[0]=Float.parseFloat(t6.text);y[1]=Float.parseFloat(t12.text);
                y[2]=Float.parseFloat(t18.text);y[3] =Float.parseFloat(t24.text);
                radio[0]=Float.parseFloat(t2.text)/3; radio[1]=Float.parseFloat(t8.text)/3;
                radio[2]=Float.parseFloat(t14.text)/3;radio[3]=Float.parseFloat(t20.text)/3;
                  }  }///fin if
             }}////fin boton graficar beta
Button    {
             text: "Graficar Gama "
             translateX:300            translateY:518
             cursor:Cursor.HAND       visible:bind vbotones
             action:function(){

              if (ejercicio3) {
               obtenerdatostabla2();validardatos4();cont2=0;erno=true;
               while (cont2<=15){
                if (verror2[cont2]!=false){
                 erno=false;} cont2++;  }/// fin while
                 if (erno!=false){  ejey();   vrec2=true;
                 cont3=2; obtenerX(cont3); xfinal[0]=z[2];
                 cont3=6; obtenerX(cont3); xfinal[1]=z[6];
                 cont3=10; obtenerX(cont3); xfinal[2]=z[10];
                 y[0]=Float.parseFloat(t6.text);y[1]=Float.parseFloat(t12.text); y[2]=Float.parseFloat(t18.text);
                 radio[0]=Float.parseFloat(t3.text)/3; radio[1]=Float.parseFloat(t9.text)/3;
                radio[2]=Float.parseFloat(t15.text)/3;radio[3]=0; } /////fin if sin errores
                }  else {
             obtenerdatostabla2();validardatos2();cont2=0;erno=true;
             while (cont2<=15){
             if (verror2[cont2]!=false){
                erno=false;} cont2++;  }/// fin while
               if (erno!=false){  ejey();   vrec2=true;
                cont3=2; obtenerX(cont3); xfinal[0]=z[2];
                cont3=6; obtenerX(cont3); xfinal[1]=z[6];
                cont3=10; obtenerX(cont3); xfinal[2]=z[10];
                cont3=14; obtenerX(cont3); xfinal[3]=z[14];
                y[0]=Float.parseFloat(t6.text);y[1]=Float.parseFloat(t12.text);
                y[2]=Float.parseFloat(t18.text);y[3] =Float.parseFloat(t24.text);
                radio[0]=Float.parseFloat(t3.text)/3;radio[1]=Float.parseFloat(t9.text)/3;
                radio[2]=Float.parseFloat(t15.text)/3;radio[3]=Float.parseFloat(t21.text)/3;
               /// Alert.inform("{xfinal[0]}+a{xfinal[1]}+b{xfinal[2]}+c{xfinal[3]}");
                   }  }///fin if
             }}////fin boton graficar  gama

  Button    {
             text: "Graficar Delta "
             translateX:300             translateY:542
             cursor:Cursor.HAND     visible:bind vbotones
             action:function(){

              if (ejercicio3) {
               obtenerdatostabla2();validardatos4();cont2=0;erno=true;
               while (cont2<=15){
                if (verror2[cont2]!=false){
                 erno=false;} cont2++;  }/// fin while
                 if (erno!=false){  ejey();  vrec2=true;
                 cont3=3; obtenerX(cont3); xfinal[0]=z[3];
                 cont3=7; obtenerX(cont3); xfinal[1]=z[7];
                 cont3=11; obtenerX(cont3); xfinal[2]=z[11];
                 y[0]=Float.parseFloat(t6.text);y[1]=Float.parseFloat(t12.text); y[2]=Float.parseFloat(t18.text);
                 radio[0]=Float.parseFloat(t4.text)/3; radio[1]=Float.parseFloat(t10.text)/3;
                radio[2]=Float.parseFloat(t16.text)/3;radio[3]=0; } /////fin if sin errores

             }else {
             
             obtenerdatostabla2();validardatos2();cont2=0;erno=true;
             while (cont2<=15){
             if (verror2[cont2]!=false){
                erno=false;} cont2++;  }/// fin while
               if (erno!=false){    ejey();   vrec2=true;
                cont3=3; obtenerX(cont3); xfinal[0]=z[3];
                cont3=7; obtenerX(cont3); xfinal[1]=z[7];
                cont3=11; obtenerX(cont3); xfinal[2]=z[11];
                cont3=15; obtenerX(cont3); xfinal[3]=z[15];
                y[0]=Float.parseFloat(t6.text);y[1]=Float.parseFloat(t12.text);
                y[2]=Float.parseFloat(t18.text);y[3] =Float.parseFloat(t24.text);
                radio[0]=Float.parseFloat(t4.text)/3;radio[1]=Float.parseFloat(t10.text)/3;
                radio[2]=Float.parseFloat(t16.text)/3;radio[3]=Float.parseFloat(t22.text)/3;
               /// Alert.inform("{xfinal[0]}+a{xfinal[1]}+b{xfinal[2]}+c{xfinal[3]}");
                }  }///fin if
             }}////fin boton calcular


///////////////////////////////////////////tabla 2 scene 1
     e1= TextBox{  /////////textbox posicion relativa
                promptText:"0 "
                translateX:24    visible:bind vtabla2
                translateY:470    columns:6
                onMouseClicked: function( e: MouseEvent ):Void  {
                vflecha=true;xflecha=24;xy=1;yx=0;
                if (ejercicio3)   {
                  xgrafica3(xy,yx); df2=(df.format(x));validar2[0]=df2;
                } else {
                  xgrafica(xy,yx);  df2=(df.format(x));validar2[0]=df2;
                } } } ////////textbox  arroz  beta
           e2= TextBox{
                promptText:"0"
                translateX:79    columns:6
                translateY:470    visible:bind vtabla2                
                onMouseClicked: function( e: MouseEvent ):Void  {
                vflecha=true;xflecha=79;xy=1;yx=1;
                if (ejercicio3)   {
                  xgrafica3(xy,yx); df2=(df.format(x));validar2[1]=df2;
                } else {
                  xgrafica(xy,yx);  df2=(df.format(x));validar2[1]=df2;
                } } } ////////////////
                e3= TextBox{
                promptText:"0"
                translateX:134   columns:6
                translateY:470   visible:bind vtabla2
                onMouseClicked: function( e: MouseEvent ):Void  {
                 vflecha=true;xflecha=134;xy=1;yx=2;
                if (ejercicio3)   {
                  xgrafica3(xy,yx); df2=(df.format(x));validar2[2]=df2;
                } else {
                  xgrafica(xy,yx);  df2=(df.format(x));validar2[2]=df2;
                } } } ////////////////
            e4= TextBox{
                promptText:"0"
                translateX:189    columns:6
                translateY:470    visible:bind vtabla2
                onMouseClicked: function( e: MouseEvent ):Void  {
                  vflecha=true;xflecha=189;xy=1;yx=3;
                if (ejercicio3)   {
                  xgrafica3(xy,yx); df2=(df.format(x));validar2[3]=df2;
                } else {
                  xgrafica(xy,yx);  df2=(df.format(x));validar2[3]=df2;
                } } } ////////////////
             e5= TextBox{
                promptText:"0"
                translateX:24     visible:bind vtabla2
                translateY:490    columns:6
                 onMouseClicked: function( e: MouseEvent ):Void  {
                  vflecha=true;xflecha=24;xy=2;yx=0;
                if (ejercicio3)   {
                  xgrafica3(xy,yx); df2=(df.format(x));validar2[4]=df2;
                } else {
                  xgrafica(xy,yx);  df2=(df.format(x));validar2[4]=df2;
                } } } ////////////////
             e6= TextBox{
                promptText:"0"     translateY:490
                translateX:79     visible:bind vtabla2
                 onMouseClicked: function( e: MouseEvent ):Void  {
                   vflecha=true;xflecha=79;xy=2;yx=1;
                if (ejercicio3)   {
                  xgrafica3(xy,yx); df2=(df.format(x));validar2[5]=df2;
                } else {
                  xgrafica(xy,yx);  df2=(df.format(x));validar2[5]=df2;
                } } } ////////////////
             e7= TextBox{
                promptText:"0"
                translateX:134    columns:6
                translateY:490    visible:bind vtabla2
                   onMouseClicked: function( e: MouseEvent ):Void  {
                  vflecha=true;xflecha=134;xy=2;yx=2;
                if (ejercicio3)   {
                  xgrafica3(xy,yx); df2=(df.format(x));validar2[6]=df2;
                } else {
                  xgrafica(xy,yx);  df2=(df.format(x));validar2[6]=df2;
                } } } ////////////////
             e8= TextBox{
                promptText:"0"
                translateX:189    columns:6
                translateY:490    visible:bind vtabla2
                onMouseClicked: function( e: MouseEvent ):Void  {
                 vflecha=true;xflecha=189;xy=2;yx=3;
                if (ejercicio3)   {
                  xgrafica3(xy,yx); df2=(df.format(x));validar2[7]=df2;
                } else {
                  xgrafica(xy,yx);  df2=(df.format(x));validar2[7]=df2;
                } } } ////////////////
             e9= TextBox{
                promptText:"0"
                translateX:24     columns:6
                translateY:510    visible:bind vtabla2
                onMouseClicked: function( e: MouseEvent ):Void  {
                   vflecha=true;xflecha=24;xy=3;yx=0;
                if (ejercicio3)   {
                  xgrafica3(xy,yx); df2=(df.format(x));validar2[8]=df2;
                } else {
                  xgrafica(xy,yx);  df2=(df.format(x));validar2[8]=df2;
                } } } ////////////////
             e10= TextBox{
                promptText:"0"
                translateX:79    columns:6
                translateY:510   visible:bind vtabla2                
                onMouseClicked: function( e: MouseEvent ):Void  {
                   vflecha=true;xflecha=79;xy=3;yx=1;
                if (ejercicio3)   {
                  xgrafica3(xy,yx); df2=(df.format(x));validar2[9]=df2;
                } else {
                  xgrafica(xy,yx);  df2=(df.format(x));validar2[9]=df2;
                } } } ////////////////
             e11= TextBox{
                promptText:"0"
                translateX:134   columns:6
                translateY:510   visible:bind vtabla2
                onMouseClicked: function( e: MouseEvent ):Void  {
                   vflecha=true;xflecha=134;xy=3;yx=2;
                if (ejercicio3)   {
                  xgrafica3(xy,yx); df2=(df.format(x));validar2[10]=df2;
                } else {
                  xgrafica(xy,yx);  df2=(df.format(x));validar2[10]=df2;
                } } } ////////////////
             e12= TextBox{
                promptText:"0"
                translateX:189    columns:6
                translateY:510    visible:bind vtabla2
                onMouseClicked: function( e: MouseEvent ):Void  {
                   vflecha=true;xflecha=189;xy=3;yx=3;
                if (ejercicio3)   {
                  xgrafica3(xy,yx); df2=(df.format(x));validar2[11]=df2;
                } else {
                  xgrafica(xy,yx);  df2=(df.format(x));validar2[11]=df2;
                } } } ////////////////
             e13= TextBox{
                promptText:"0"
                translateX:24     columns:6
                translateY:530    visible:bind vtabla2
                onMouseClicked: function( e: MouseEvent ):Void  {
                vflecha=true;xflecha=24;xy=4;yx=0;  xgrafica(xy,yx);
                df2=(df.format(x));validar2[12]=df2; }
                  }////////textbox  trigo beta
             e14= TextBox{
                promptText:"0"
                translateX:79     columns:6
                translateY:530    visible:bind vtabla2
                onMouseClicked: function( e: MouseEvent ):Void  {
                vflecha=true;xflecha=79;xy=4;yx=1;  xgrafica(xy,yx);
                df2=(df.format(x));validar2[13]=df2; }
                 }////////textbox  trigo gama
             e15= TextBox{
                promptText:"0"
                translateX:134    columns:6
                translateY:530    visible:bind vtabla2
                onMouseClicked: function( e: MouseEvent ):Void  {
                vflecha=true;xflecha=134;xy=4;yx=2;  xgrafica(xy,yx);
                df2=(df.format(x));validar2[14]=df2; }
                   }////////textbox  trigo delta
             e16= TextBox{
                promptText:"0"
                translateX:189    columns:6
                translateY:530   visible:bind vtabla2
                onMouseClicked: function( e: MouseEvent ):Void  {
                vflecha=true;xflecha=189;xy=4;yx=3;  xgrafica(xy,yx);
                df2=(df.format(x));validar2[15]=df2; }
                     }////////  fin  textbox totales
////////////////////////////rectangulos
 Rectangle {  //////rec 1  alfa
    x:24  y:280
    fill: Color.RED
    width:50  height: 18 }
 Rectangle {  //////rec 2  beta
    x:79  y: 280
    fill: Color.GREEN
    width:50   height: 18 }
Rectangle {  //////rec 3  gama
    x:134  y:280
    fill: Color.YELLOW
    width:50  height: 18 }
Rectangle {  //////rec 4  delta
    x:189  y:280
    fill: Color.BLUE
    width:50  height: 18 }

///////////////////////rectangulos tabla 2 scene 1
Rectangle {  //////rec 1  alfa
    x:24  y: 450
    fill: Color.RED
    cursor:Cursor.HAND
    width:50  height: 18
              }///////fin rectangulo

 Rectangle {  //////rec 2  beta
    x:79  y: 450
    fill: Color.GREEN
    width:50  height: 18
     cursor:Cursor.HAND     
    } /////fin rectangulo 2
Rectangle {  //////rec 3  gama
    x:134  y: 450
    fill: Color.YELLOW
    width:50  height: 18 
    cursor:Cursor.HAND     
    }////////fin rectangulo 3
Rectangle {  //////rec 4  delta
    x:189  y: 450
    fill: Color.BLUE
    width:50  height: 18
    cursor:Cursor.HAND       }

//////////////////////////////////////fin rectangulos
////"Segmentacion " bind segmentacion[cont4];
 Label{
            text:bind "Segmentacion {segmentacion[cont4]}"
            translateX:320
            translateY:230
            textFill: Color.BLUE
           ///// layoutInfo: LayoutInfo {width: 240 height: 300}
            font: Font {name: "Tahoma" size: 18}
        }/////fin label

 Label{
            text: "Ventas Actuales";
            translateX:250       translateY:280
             textFill: Color.BLUE
            font: Font {name: "Tahoma" size: 11} }
Label{
            text: "Ventas Historicas";
            translateX:340       translateY:280
             textFill: Color.BLUE
            font: Font {name: "Tahoma" size: 11} }
Label{
            text: "Crecimiento Anual";
            translateX:440       translateY:280
             textFill: Color.BLUE
            font: Font {name: "Tahoma" size: 11} }
Label{
            text: "Eligir el criterio de Segmentación";
            translateX:80      translateY:574
             textFill: Color.BLUE  visible:bind vbotones
            font: Font {name: "Tahoma" size: 18} }

///////////////////////////////labels grafica
Label{
            text: "0.06X";
            translateX:640
            translateY:614
            visible:bind vlabel
            font: Font {name: "Tahoma" size: 12}  }
Label{  //////////////label 2
            text: "0.12X";
            translateX:686
            translateY:614
            visible:bind vlabel
            font: Font {name: "Tahoma" size: 12}  }
Label{  //////////////////label  3
            text: "0.25X";
            translateX:730
            translateY:614
            visible:bind vlabel
            font: Font {name: "Tahoma" size: 12}  }
Label{
            text: "0.5X";
            translateX:776
            translateY:614
            visible:bind vlabel
            font: Font {name: "Tahoma" size: 12}  }
Label{
            text: "1X";
            translateX:820
            translateY:614
            visible:bind vlabel
            font: Font {name: "Tahoma" size: 12}  }
Label{
            text: "2X";
            translateX:862
            translateY:614
            visible:bind vlabel
            font: Font {name: "Tahoma" size: 12}  }
Label{
            text: "4X";
            translateX:900
            translateY:614
            visible:bind vlabel
            font: Font {name: "Tahoma" size: 12}  }
Label{
            text: "8X";
            translateX:940
            translateY:614
            visible:bind vlabel
            font: Font {name: "Tahoma" size: 12}  }
    ////////////////////////////fin label grafica
 Label{  ////////////////////label  tabla 1
            text:bind "{segmento1[label1]}"
            translateX:2
            translateY:302    textFill: Color.BLUE
            font: Font {name: "Tahoma" size: 16 }  }
  Label{  ////////////////////label  avena
            text:bind "{segmento1[label2]}"
            translateX:2
            translateY:322    textFill: Color.BLUE
            font: Font {name: "Tahoma" size: 16 }  }
 Label{  ////////////////////label  tabla 1
            text:bind "{segmento1[label3]}"
            translateX:2
            translateY:342    textFill: Color.BLUE
            font: Font {name: "Tahoma" size: 16 }  }
 Label{  ////////////////////label  tabla 1
            text:bind "{segmento1[label4]}"
            translateX:2
            translateY:362    textFill: Color.BLUE
            font: Font {name: "Tahoma" size: 16 }  }

error,error1,error2,error3,error4,error5,error6,error7,error8,error9,error10,
error11,error12,error13,error14,error15,alerta,alerta2,alerta3,alerta4,alerta5,
alerta6,alerta7,alerta8,alerta9,alerta10,alerta11,alerta12,alerta13,alerta14,
alerta15,alerta16,
         ]////////content scene 1
          }////////////////////////////////////////////////////scene 1

 

  ////////////////////////////////////////////////////////////fin scene 3
    

    }////stage