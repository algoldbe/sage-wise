
package matrizbcg;

import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.chart.part.*;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.shape.*;
import javafx.scene.text.Font;
import javafx.scene.paint.Color;
import javafx.scene.image.*;
import javafx.scene.image.ImageView;
import javafx.scene.Cursor;
/////import javafx.scene.text.Text;
///import javafx.scene.layout.LayoutInfo;

////////////////////variables
var n:TextBox; var n2:TextBox; var n3:TextBox;var n4:TextBox; var lim2=0.0;
var x=0.0; var x2=0.0;var x3=0.0; var x4=0.0;
var limsup=0.0;var liminf=0.0;var cont=0;var z=[0.0,0.0,0.0,0.0,0.0];
var radio=[0.0,0.0,0.0,0.0,0.0];var y=[0.0,0.0,0.0,0.0,0.0];
var xslider= Slider {min:164 max:590 value:372    translateX:440  translateY:440};
var yslider= Slider {min:74 max:382  value:250    translateX:80  translateY:150  vertical:true};
///////////////////////////////////imagenes
////////imagen signo interrogacion
var duda = Image {
     url: "{__DIR__}imagenes/01.jpg"

    };
var duda1 = ImageView {
   image:duda
    x:166
    y:80
    id:"duda"
   };/////////////////// imagen sol
var sol = Image {
     url: "{__DIR__}imagenes/sol.gif"

    };
var sol1 = ImageView {
   image:sol
    x:560
    y:80
    id:"sol"
   };///////////////tumba
 var tumba = Image {
     url: "{__DIR__}imagenes/rip.jpg"

    };
var tumba1 = ImageView {
   image:tumba
    x:166
    y:354
    id:"sol"
   };////////////signo de dolar
   var dolar = Image {
     url: "{__DIR__}imagenes/Dolar.jpg"

    };
var dolar1 = ImageView {
   image:dolar
    x:560
    y:340
    id:"sol"
   };////////////
////////////////////////////////////stage
Stage {
    title: "Graficador de Sectores de Negocios"
    scene: Scene {
        width: 800
        height: 620

        content: [ duda1,sol1,tumba1,dolar1,xslider,yslider,
           /////////////////////grafica burbujas
           BubbleChart {
        scaleBubbleRadiusUsingAxis: false
        legendVisible:false
        translateX:100
        translateY:40
        title : "Matriz BCG"
                xAxis : NumberAxis{
                    lowerBound:0
                    upperBound : 16
                    visible:true
                    axisStrokeWidth: 1
                    label:"Posicion competitiva relativa"                    
                    tickLabelsVisible: false
                    tickUnit : 2

                }
                yAxis : NumberAxis{
                    lowerBound: -4
                    upperBound : 12
                    tickUnit: 2
                    label: "Crecimiento anual del Sector %"
                    visible: true
                    tickLabelsVisible: true
                    }
        data: [
            BubbleChart.Series {
                
                data: [
                    ////////primer circulo
                    BubbleChart.Data {
                     xValue: bind  z[1]
                     yValue: bind y[1]
                     radius: bind radio[1]
                     }    /////////segundo circulo
                    BubbleChart.Data {
                     xValue: bind  z[2]
                     yValue: bind y[2]
                     radius: bind radio[2]
                     fill: Color.YELLOWGREEN
                   } //////tercer  circulo
                      BubbleChart.Data {
                     xValue: bind  z[3]
                     yValue: bind y[3]
                     radius: bind radio[3]
                     fill: Color.BLUEVIOLET
                   } ////////cuarto  circulo
                    BubbleChart.Data {
                     xValue: bind  z[4]
                     yValue: bind y[4]
                     radius: bind radio[4]
                     fill: Color.FIREBRICK
                   } //////quinto circulo
                    BubbleChart.Data {
                     xValue: bind  z[5]
                     yValue: bind y[5]
                     radius: bind radio[5]
                     fill: Color.BLACK
                   } /////////sexto circulo
                   BubbleChart.Data {
                     xValue: bind  z[6]
                     yValue: bind y[6]
                     radius: bind radio[6]
                     fill: Color.DARKGREEN
                   } //////////septimo circulo
                   BubbleChart.Data {
                     xValue: bind  z[7]
                     yValue: bind y[7]
                     radius: bind radio[7]
                     fill: Color.SILVER
                   } ///////octavo circulo
                   BubbleChart.Data {
                     xValue: bind  z[8]
                     yValue: bind y[8]
                     radius: bind radio[8]
                     fill: Color.LIGHTPINK
                   } ////////noveno circuolo
                   BubbleChart.Data {
                     xValue: bind  z[9]
                     yValue: bind y[9]
                     radius: bind radio[9]
                     fill: Color.ORANGE
                   } ////////////decimo circulo
                   BubbleChart.Data {
                     xValue: bind  z[10]
                     yValue: bind y[10]
                     radius: bind radio[10]
                     fill: Color.BLUE
                   } ///////

                ]//////data
            }///////buble chart series
         ]////////////data grafica
        }////fin grafica

/////////////////////////////////////labels
Label{
            text: "0.06X";
            translateX:200
            translateY:394
            font: Font {name: "Tahoma" size: 12}
        }////////////label 2
Label{
            text:"0.12X";
            translateX:250
            translateY:394
            font: Font {name: "Tahoma" size: 12}
        }////////////label 3
Label{
            text:"0.25X";
            translateX:300
            translateY:394
            font: Font {name: "Tahoma" size: 12}
        }//////////label 4
Label{
            text:"0.5X";
            translateX:360
            translateY:394
            font: Font {name: "Tahoma" size: 12}
        }//////////label  5
Label{
            text:"1X";
            translateX:420
            translateY:394
            font: Font {name: "Tahoma" size: 12}
        }//////////label 6
Label{
            text:"2X";
            translateX:480
            translateY:394
            font: Font {name: "Tahoma" size: 12}
        }///////////////label 7
Label{
            text:"4X";
            translateX:530
            translateY:394
            font: Font {name: "Tahoma" size: 12}
        }////////////label 8
Label{
            text:"8X";
            translateX:590
            translateY:394
            font: Font {name: "Tahoma" size: 12}
        }///////////
///////////////////lineas  matriz bcg
Rectangle {  //////rec 1
    x:bind xslider.value   y: 76
    fill: Color.GREEN
    width:4  height:310
}//////rec 2
Rectangle {  ////////rec 2
    x:168  y:bind yslider.value
    fill: Color.GREEN
    width:430  height:4 ////  visible:bind vx5
}

///////////////////////////////////textbox
Label{
            text:"Especifique el tamaño del sector:";
            translateX:100
            translateY:500
            font: Font {name: "Tahoma" size: 12}
        }
 ////textbox porcentaje y
          n= TextBox{
                promptText:"14.0"
                translateX:300
                translateY:500
                columns:8
            }/////////////////coordenada y
  Label{
            text:"Especifique la coordenada y:";
            translateX:100
            translateY:530
            font: Font {name: "Tahoma" size: 12}
        }

   Label{
            text:"%";
            translateX:370            translateY:534
            font: Font {name: "Tahoma" size: 12}
        }
            ////////textbox  fraccion x
          n2= TextBox{
                promptText:"3.0"
                translateX:300
                translateY:530
                columns:8
            }////////// radio del circulo
   Label{
            text:"Especifique la coordenada x:";
            translateX:100
            translateY:560
            font: Font {name: "Tahoma" size: 12}
        }

   Label{
            text:"X";
            translateX:370            translateY:564
            font: Font {name: "Tahoma" size: 12}
        }

          n3= TextBox{
                promptText:" 0.24 "
                translateX:300
                translateY:560
                columns:8
                }////////////crecimiento anual de la industria

  ////////////////////posicionamiento de la industria  
     Label{
            text:"Especifique el criterio de posicionamiento:";
            translateX:160
            translateY:440
            font: Font {name: "Tahoma" size: 12}        }
  

///////////////////////botones
Button{
            text:"Siguiente"
            translateX:400
            translateY:500
            cursor:Cursor.HAND
            action:function(){
            cont=cont+1;
            radio[cont] =Float.parseFloat(n.text);
            y[cont] =Float.parseFloat(n2.text);
            x =Float.parseFloat(n3.text);

            //////////////////////////validar x            
            if (x<=0.06 and x>=0.0){
                lim2=0; liminf=0;limsup=0.06;
                liminf=liminf-lim2;
                limsup=limsup-lim2;
                x=x-lim2;
                
                x2=(x*100)/limsup;
                x3=(x2*2)/100;
                z[cont]=x3+0;
                }   //////////segundo intervalo 0.12x
             if (x<=0.12 and x>=0.06){
                 liminf=0.06;lim2=0.06;limsup=0.12;
                liminf=liminf-lim2;
                limsup=limsup-lim2;
                x=x-lim2;

                x2=(x*100)/limsup;
                x3=(x2*2)/100;
                 z[cont]=x3+2;
                }  //////////// terecer intervalo 0.25 x
             if (x<=0.25 and x>=0.12){
                 liminf=0.12;lim2=0.12;limsup=0.25;
                liminf=liminf-lim2;
                limsup=limsup-lim2;
                x=x-lim2;

                x2=(x*100)/limsup;
                x3=(x2*2)/100;
                 z[cont]=x3+4;
                }//////////////cuarto intervalo 0.5 x
             if (x<=0.5 and x>=0.25){
                 liminf=0.25;lim2=0.25;limsup=0.50;
                liminf=liminf-lim2;
                limsup=limsup-lim2;
                x=x-lim2;

                x2=(x*100)/limsup;
                x3=(x2*2)/100;
                 z[cont]=x3+6;
                }////////////////quinto intervalo 1 x
             if (x<=1.0 and x>=0.5){
                 liminf=0.5;lim2=0.5;limsup=1.0;
                liminf=liminf-lim2;
                limsup=limsup-lim2;
                x=x-lim2;

                x2=(x*100)/limsup;
                x3=(x2*2)/100;
                 z[cont]=x3+8;
                }////////////////sexto intervalo 2x
             if (x<=2.0 and x>=1.0){
                 liminf=1.0;lim2=1.0;limsup=2.0;
                liminf=liminf-lim2;
                limsup=limsup-lim2;
                x=x-lim2;

                x2=(x*100)/limsup;
                x3=(x2*2)/100;
                 z[cont]=x3+10;
                }/////////////////septimo intervalo 4x
              if (x<=4.0 and x>=2.0){
                 liminf=2.0;lim2=2.0;limsup=4.0;
                liminf=liminf-lim2;
                limsup=limsup-lim2;
                x=x-lim2;

                x2=(x*100)/limsup;
                x3=(x2*2)/100;
                 z[cont]=x3+12;
                }///////////////////octavo intervalo 8x
             if (x<=8.0 and x>=4.0){
                 liminf=4.0;lim2=4.0;limsup=8.0;
                liminf=liminf-lim2;
                limsup=limsup-lim2;
                x=x-lim2;

                x2=(x*100)/limsup;
                x3=(x2*2)/100;
                 z[cont]=x3+14; ////cont=1;
                }//////////////////fin  intervalos
    
            }//////fin fuction
            }///////fin boton
//////////////////////////////boton reestablecer
Button{
            text:"Nuevo Diagrama"
            translateX:400
            translateY:530
            cursor:Cursor.HAND
            action:function(){
            x=0;y=0;z=0; radio=0; x=0;x2=0;x3=0;x4=0;
            n.text="";n2.text="";n3.text="";n4.text="";
            }////fin fuction
            }//////////////fin boton nuevo diagrama

        ]//////content
    }//////scene
}//////stage